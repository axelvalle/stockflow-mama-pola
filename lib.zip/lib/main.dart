import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:mamapola_app_v1/view/inicio/dashboard_page.dart';
import 'package:mamapola_app_v1/view/auth/login_page.dart';
import 'package:mamapola_app_v1/view/auth/signup_page.dart';
import 'package:mamapola_app_v1/view/inicio/lets_startpage.dart';
import 'package:mamapola_app_v1/view/inicio/splashscreen.dart';
import 'package:mamapola_app_v1/view/proveedor/proveedor_page.dart';
import 'package:mamapola_app_v1/view/proveedor/proveedor_form.dart';
import 'package:mamapola_app_v1/view/empresa/empresa_page.dart';
import 'package:mamapola_app_v1/view/empresa/empresa_form.dart';
import 'package:mamapola_app_v1/view/producto/producto_page.dart';
import 'package:mamapola_app_v1/view/producto/producto_form.dart';
import 'package:mamapola_app_v1/view/categoria/categoria_page.dart';
import 'package:mamapola_app_v1/view/categoria/categoria_form.dart';
import 'package:mamapola_app_v1/model/exceptions/ui_errorhandle.dart';
import 'package:mamapola_app_v1/logic/injection/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");

  try {
    String supabaseUrl = dotenv.env['SUPABASE_URL'] ?? '';
    String supabaseAnonKey = dotenv.env['SUPABASE_ANON_KEY'] ?? '';

    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: supabaseAnonKey,
    );

    runApp(
      const ProviderScope(child: MyApp()),
    );
  } catch (e) {
    runApp(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text('Error inicial: ${UIErrorHandler.getFriendlyMessage(e)}'),
          ),
        ),
      ),
    );
  }
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: 'Mama Pola App',
      theme: ThemeData(primarySwatch: Colors.blue),
      darkTheme: ThemeData.dark(),
      themeMode: themeMode,
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginPage(),
        '/signup': (context) => const SignUpPage(),
        '/dashboard': (context) => const DashboardPage(),
        '/letsstart': (context) => const LetsStartPage(),
        '/proveedores': (context) => const ProveedorPage(),
        '/proveedor_form': (context) => const ProveedorForm(),
        '/empresas': (context) => const EmpresaPage(),
        '/empresa_form': (context) => const EmpresaForm(),
        '/productos': (context) => const ProductoPage(),
        '/producto_form': (context) => const ProductoForm(),
        '/categorias': (context) => const CategoriaPage(),
        '/categoria_form': (context) => const CategoriaForm(),
      },
      builder: (context, child) {
        ErrorWidget.builder = (errorDetails) {
          UIErrorHandler.showError(
            context,
            errorDetails.exception,
            displayType: ErrorDisplayType.dialog,
            customTitle: 'Error crítico',
          );
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        };
        return child!;
      },
    );
  }
}