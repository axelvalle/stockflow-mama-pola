import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/view/empresa/empresa_form.dart';
import 'package:mamapola_app_v1/logic/empresa/empresa_controller.dart';

class EmpresaPage extends ConsumerStatefulWidget {
  const EmpresaPage({super.key});

  @override
  ConsumerState<EmpresaPage> createState() => _EmpresaPageState();
}

class _EmpresaPageState extends ConsumerState<EmpresaPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(empresaControllerProvider.notifier).cargarEmpresas();
    });
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.watch(empresaControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Empresas'),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await ref.read(empresaControllerProvider.notifier).cargarEmpresas();
        },
        child: controller.isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: controller.empresas.length,
                itemBuilder: (context, index) {
                  final empresa = controller.empresas[index];

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ExpansionTile(
                      leading: const Icon(Icons.business),
                      title: Text(
                        empresa.nombreempresa,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: Text(empresa.direccion ?? 'Sin dirección'),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'editar') {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    EmpresaForm(empresa: empresa),
                              ),
                            );
                            if (result == true) {
                              ref
                                  .read(empresaControllerProvider.notifier)
                                  .cargarEmpresas();
                            }
                          } else if (value == 'eliminar') {
                            final confirm = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Confirmar eliminación'),
                                content: const Text(
                                    '¿Estás seguro de que deseas eliminar esta empresa? Esta acción no se puede deshacer.'),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, false),
                                    child: const Text('Cancelar'),
                                  ),
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, true),
                                    child: const Text(
                                      'Eliminar',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              ),
                            );
                            if (confirm == true) {
                              await ref
                                  .read(empresaControllerProvider.notifier)
                                  .eliminarEmpresa(empresa.idempresa);
                            }
                          }
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(
                            value: 'editar',
                            child: Text('Editar'),
                          ),
                          const PopupMenuItem(
                            value: 'eliminar',
                            child: Text('Eliminar'),
                          ),
                        ],
                      ),
                      childrenPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.phone, size: 16),
                            const SizedBox(width: 6),
                            Text(
                              'Contacto: ${empresa.contacto ?? "N/A"}',
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Proveedores asociados:',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        if (empresa.proveedores.isEmpty)
                          const Text('No hay proveedores asociados.')
                        else
                          Column(
                            children: empresa.proveedores.map((prov) {
                              final persona = prov.persona;
                              return ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: const Icon(Icons.person),
                                title: Text(
                                  '${persona?.primerNombre ?? ''} ${persona?.primerApellido ?? ''}',
                                ),
                                subtitle:
                                    Text(persona?.telefono ?? 'Sin teléfono'),
                              );
                            }).toList(),
                          ),
                      ],
                    ),
                  );
                },
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const EmpresaForm()),
          );
          if (result == true) {
            ref.read(empresaControllerProvider.notifier).cargarEmpresas();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
