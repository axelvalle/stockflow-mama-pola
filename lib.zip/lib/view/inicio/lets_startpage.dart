import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../logic/injection/theme_provider.dart';

class LetsStartPage extends ConsumerWidget {
  const LetsStartPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final size = MediaQuery.of(context).size;
    final themeMode = ref.watch(themeModeProvider);
    final isDarkTheme = themeMode == ThemeMode.dark;

    final primaryColor = Theme.of(context).colorScheme.primary;
    final onPrimaryColor = Theme.of(context).colorScheme.onPrimary;
    //final primaryVariant = Theme.of(context).colorScheme.primaryContainer;

    return Scaffold(
      backgroundColor: isDarkTheme ? Colors.grey.shade900 : Colors.grey.shade100,
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Material(
                      elevation: 4,
                      shape: const CircleBorder(),
                      clipBehavior: Clip.antiAlias,
                      child: CircleAvatar(
                        backgroundColor: isDarkTheme ? Colors.grey.shade800 : Colors.white,
                        radius: size.width * 0.18,
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Image.asset('assets/logo1.png'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),

                    Text(
                      'Powered by StockFlow v1.0',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            color: isDarkTheme ? primaryColor.withOpacity(0.8) : primaryColor,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                            fontSize: 20,
                          ),
                    ),
                    const SizedBox(height: 8),

                    Text(
                      'Gestión eficiente y sencilla de inventarios',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: isDarkTheme ? Colors.grey.shade300 : Colors.grey.shade700,
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                    const SizedBox(height: 40),

                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 6,
                      shadowColor: primaryColor.withOpacity(0.3),
                      color: isDarkTheme ? Colors.grey.shade800 : Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                        child: Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                icon: const Icon(Icons.login_outlined),
                                label: const Text(
                                  'Iniciar sesión',
                                  style: TextStyle(fontSize: 18),
                                ),
                                onPressed: () {
                                  Navigator.pushNamed(context, '/login');
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryColor,
                                  foregroundColor: onPrimaryColor,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  elevation: 4,
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.app_registration_outlined),
                                label: const Text(
                                  'Registrarse',
                                  style: TextStyle(fontSize: 18),
                                ),
                                onPressed: () {
                                  Navigator.pushNamed(context, '/signup');
                                },
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: primaryColor,
                                  side: BorderSide(
                                    color: primaryColor,
                                  ),
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),

                    Text(
                      '© Derechos Reservados Axel Valle 2025',
                      style: TextStyle(
                        color: isDarkTheme ? Colors.grey.shade400 : Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 12,
              right: 12,
              child: Row(
                children: [
                  Icon(
                    isDarkTheme ? Icons.dark_mode : Icons.light_mode,
                    color: primaryColor,
                  ),
                  Switch(
                    value: isDarkTheme,
                    activeColor: primaryColor,
                    onChanged: (_) => toggleTheme(ref),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
