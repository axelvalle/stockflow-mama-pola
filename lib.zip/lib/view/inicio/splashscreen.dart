import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<bool>(
        future: _checkSession(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/logo1.png'),
                  SizedBox(height: 20),
                  CircularProgressIndicator(),
                  SizedBox(height: 10),
                  Text('Cargando Mama Pola App...'),
                ],
              ),
            );
          } else {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (snapshot.data == true) {
                Navigator.pushReplacementNamed(context, '/letsstart');
              } else {
                Navigator.pushReplacementNamed(context, '/letsstart');
              }
            });
            return const SizedBox.shrink();
          }
        },
      ),
    );
  }

  Future<bool> _checkSession() async {
    final user = Supabase.instance.client.auth.currentUser;
    await Future.delayed(const Duration(seconds: 2)); // Simula carga
    return user != null;
  }
}
