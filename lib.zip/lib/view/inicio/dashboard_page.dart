import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/logic/utils/greetings_util.dart';
import 'package:mamapola_app_v1/view/inicio/lets_startpage.dart';
import 'package:mamapola_app_v1/logic/auth/auth_service.dart';
import 'package:mamapola_app_v1/model/exceptions/ui_errorhandle.dart';
import 'package:mamapola_app_v1/logic/auth/inactivity_service.dart'; // Nuevo import
import '../../logic/injection/theme_provider.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  int _currentIndex = 0;

  Future<void> _logout(BuildContext context) async {
    try {
      await AuthService.logout(context);
      if (!context.mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LetsStartPage()),
        (route) => false,
      );
    } catch (e) {
      UIErrorHandler.showError(context, e);
    }
  }

  void _toggleTheme() {
    toggleTheme(ref);
  }

  Widget _buildFeatureTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    double? width,
  }) {
    return InkWell(
      onTap: () {
        ref.read(inactivityProvider.notifier).resetInactivityTime();
        onTap();
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: width ?? 100,
        height: width ?? 100,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: (width ?? 100) * 0.3, color: Colors.white),
            SizedBox(height: (width ?? 100) * 0.1),
            Flexible(
              child: Text(
                label,
                style: const TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestionTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    double? width,
  }) {
    return InkWell(
      onTap: () {
        ref.read(inactivityProvider.notifier).resetInactivityTime();
        onTap();
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: width ?? 110,
        height: (width ?? 110) * 0.55,
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: const TextStyle(color: Colors.white),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFeatureNotAvailable(BuildContext context) {
    ref.read(inactivityProvider.notifier).resetInactivityTime();
    UIErrorHandler.showError(
      context,
      'Esta funcionalidad estará disponible pronto',
      displayType: ErrorDisplayType.snackBar,
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final greeting = GreetingUtils.getGreeting();

    double featureTileWidth;
    double suggestionTileWidth;

    if (screenWidth >= 1200) {
      featureTileWidth = 150;
      suggestionTileWidth = 170;
    } else if (screenWidth >= 800) {
      featureTileWidth = 130;
      suggestionTileWidth = 150;
    } else {
      featureTileWidth = 100;
      suggestionTileWidth = 110;
    }

    return InactivityDetector(
      child: Scaffold(
        appBar: AppBar(
          title: Text(greeting),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () => _logout(context),
              tooltip: 'Cerrar sesión',
            )
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: LayoutBuilder(builder: (context, constraints) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Accesos Rápidos",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _buildFeatureTile(
                      icon: Icons.people,
                      label: "Clientes",
                      color: Colors.indigo,
                      onTap: () => _showFeatureNotAvailable(context),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.local_shipping,
                      label: "Proveedores",
                      color: Colors.orange,
                      onTap: () => Navigator.pushNamed(context, '/proveedores'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.shopping_bag,
                      label: "Productos",
                      color: Colors.purple,
                      onTap: () => Navigator.pushNamed(context, '/productos'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.category,
                      label: "Categorías",
                      color: Colors.pinkAccent,
                      onTap: () => Navigator.pushNamed(context, '/categorias'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.inventory,
                      label: "Inventario",
                      color: Colors.blue,
                      onTap: () => Navigator.pushNamed(context, '/inventario'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.swap_vert,
                      label: "Entradas/Salidas",
                      color: Colors.brown,
                      onTap: () => Navigator.pushNamed(context, '/movimientos'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.apartment,
                      label: "Empresas",
                      color: Colors.blueGrey,
                      onTap: () => Navigator.pushNamed(context, '/empresas'),
                      width: featureTileWidth,
                    ),
                    _buildFeatureTile(
                      icon: Icons.bar_chart,
                      label: "Estadísticas",
                      color: Colors.deepPurple,
                      onTap: () => Navigator.pushNamed(context, '/estadisticas'),
                      width: featureTileWidth,
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.lightBlue.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.lightBlue.shade100),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.insights, color: Colors.lightBlue),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          "¡Revisa tus estadísticas y mantén el control de inventario actualizado en tiempo real!",
                          style: TextStyle(fontSize: 14, color: Colors.blueAccent),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text("Sugerencias",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildSuggestionTile(
                      icon: Icons.add,
                      label: "Agregar Producto",
                      color: Colors.green,
                      onTap: () => Navigator.pushNamed(context, '/agregar_producto'),
                      width: suggestionTileWidth,
                    ),
                    _buildSuggestionTile(
                      icon: Icons.warning,
                      label: "Stock Bajo",
                      color: Colors.amber,
                      onTap: () => Navigator.pushNamed(context, '/alertas_stock'),
                      width: suggestionTileWidth,
                    ),
                    _buildSuggestionTile(
                      icon: Icons.factory,
                      label: "Proveedores por Empresa",
                      color: Colors.indigo,
                      onTap: () => Navigator.pushNamed(context, '/empresas'),
                      width: suggestionTileWidth,
                    ),
                  ],
                ),
              ],
            );
          }),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            ref.read(inactivityProvider.notifier).resetInactivityTime();
            if (index == 2) {
              _toggleTheme();
            } else {
              setState(() {
                _currentIndex = index;
              });
            }
          },
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Inicio'),
            BottomNavigationBarItem(icon: Icon(Icons.inventory), label: 'Inventario'),
            BottomNavigationBarItem(icon: Icon(Icons.brightness_6), label: 'Tema'),
          ],
        ),
      ),
    );
  }
}