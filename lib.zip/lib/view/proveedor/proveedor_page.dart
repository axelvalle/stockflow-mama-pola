import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/logic/proveedor/proveedor_controller.dart';
import 'package:mamapola_app_v1/view/proveedor/proveedor_form.dart';

class ProveedorPage extends ConsumerStatefulWidget {
  const ProveedorPage({super.key});

  @override
  ConsumerState<ProveedorPage> createState() => _ProveedorPageState();
}

class _ProveedorPageState extends ConsumerState<ProveedorPage> {
  @override
  void initState() {
    super.initState();
    // Carga inicial de proveedores al montar el widget
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(proveedorControllerProvider.notifier).loadProveedores();
    });
  }

  Future<void> _refresh() async {
    await ref.read(proveedorControllerProvider.notifier).loadProveedores();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(proveedorControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Proveedores'),
        centerTitle: true,
        elevation: 2,
        actions: [
          IconButton(
            tooltip: 'Refrescar lista',
            icon: const Icon(Icons.refresh),
            onPressed: state.isLoading ? null : _refresh,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: state.isLoading
            ? const Center(child: CircularProgressIndicator())
            : state.proveedores.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, size: 60, color: Colors.grey),
                        SizedBox(height: 12),
                        Text(
                          "No hay proveedores registrados.",
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _refresh,
                    child: ListView.builder(
                      itemCount: state.proveedores.length,
                      itemBuilder: (context, index) {
                        final proveedor = state.proveedores[index];
                        final persona = proveedor.persona;

                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 3,
                          child: ListTile(
                            leading: CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.teal.shade300,
                              child: const Icon(Icons.person, color: Colors.white),
                            ),
                            title: Text(
                              '${persona?.primerNombre ?? ''} ${persona?.primerApellido ?? ''}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            ),
                            subtitle: Text(
                              persona?.telefono ?? 'Teléfono no disponible',
                              style: const TextStyle(fontSize: 14),
                            ),
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) async {
                                if (value == 'editar') {
                                  final result = await Navigator.push<bool>(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => ProveedorForm(persona: persona),
                                    ),
                                  );
                                  if (result == true) {
                                    await _refresh();
                                  }
                                } else if (value == 'eliminar') {
                                  final confirm = await showDialog<bool>(
                                    context: context,
                                    builder: (_) => AlertDialog(
                                      title: const Text('¿Eliminar proveedor?'),
                                      content: const Text('Esta acción no se puede deshacer.'),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(context, false),
                                          child: const Text('Cancelar'),
                                        ),
                                        ElevatedButton(
                                          onPressed: () => Navigator.pop(context, true),
                                          child: const Text('Eliminar'),
                                        ),
                                      ],
                                    ),
                                  );

                                  if (confirm == true && persona?.idpersona != null) {
                                    await ref.read(proveedorControllerProvider.notifier).eliminarProveedor(persona!.idpersona!);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Proveedor eliminado')),
                                    );
                                    await _refresh();
                                  }
                                }
                              },
                              itemBuilder: (context) => const [
                                PopupMenuItem(value: 'editar', child: Text('Editar')),
                                PopupMenuItem(value: 'eliminar', child: Text('Eliminar')),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        tooltip: 'Agregar nuevo proveedor',
        onPressed: () async {
          final result = await Navigator.push<bool>(
            context,
            MaterialPageRoute(builder: (_) => const ProveedorForm()),
          );

          if (result == true) {
            await _refresh();
          }
        },
        icon: const Icon(Icons.add),
        label: const Text("Nuevo"),
      ),
    );
  }
}
