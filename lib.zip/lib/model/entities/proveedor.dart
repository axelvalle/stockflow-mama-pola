import 'persona.dart';

class Proveedor {
  final int? id;
  final int idPersona;
  final Persona? persona;

  Proveedor({this.id, required this.idPersona, this.persona});

  factory Proveedor.fromMap(Map<String, dynamic> map) => Proveedor(
    id: map['idproveedor'],
    idPersona: map['idpersona'],
    persona: map['persona'] != null ? Persona.fromMap(map['persona']) : null,
  );

  Map<String, dynamic> toMap() => {
    'idpersona': idPersona,
  };
}
