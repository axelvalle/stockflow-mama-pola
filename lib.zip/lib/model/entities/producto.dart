class Producto {
  final int? idproducto;
  final String nombreproducto;
  final double precio;
  final int idcategoria;
  final int idproveedor;
  final String? estado;
  final String? imagenUrl;

  Producto({
    this.idproducto,
    required this.nombreproducto,
    required this.precio,
    required this.idcategoria,
    required this.idproveedor,
    this.estado,
    this.imagenUrl,
  });

  factory Producto.fromMap(Map<String, dynamic> map) {
    return Producto(
      idproducto: map['idproducto'] as int?,
      nombreproducto: map['nombreproducto'] as String,
      precio: (map['precio'] as num).toDouble(),
      idcategoria: map['idcategoria'] as int,
      idproveedor: map['idproveedor'] as int,
      estado: map['estado'] as String?,
      imagenUrl: map['imagen_url'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'idproducto': idproducto,
      'nombreproducto': nombreproducto,
      'precio': precio,
      'idcategoria': idcategoria,
      'idproveedor': idproveedor,
      'estado': estado,
      'imagen_url': imagenUrl,
    };
  }
}