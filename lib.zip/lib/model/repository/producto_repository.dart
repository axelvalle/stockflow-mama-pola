import 'dart:io';

import 'package:mamapola_app_v1/logic/producto/producto_controller.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:mamapola_app_v1/model/entities/producto.dart';

class ProductoRepository {
  final _client = Supabase.instance.client;

Future<List<Producto>> listarProductos() async {
  try {
    final response = await _client
        .from('producto')
        .select('idproducto, nombreproducto, precio, idcategoria, idproveedor, estado, imagen_url')
        .order('idproducto', ascending: true);

    final productos = (response as List<dynamic>).map((map) => Producto.fromMap(map)).toList();

    // Generar URLs firmadas para imágenes si el bucket es privado
    for (var producto in productos) {
      if (producto.imagenUrl != null && producto.imagenUrl!.isNotEmpty) {
        try {
          final signedUrl = await _client.storage
              .from('productos')
              .createSignedUrl(producto.imagenUrl!.replaceFirst('productos/', ''), 3600);
          producto = producto.copyWith(imagenUrl: signedUrl);
        } catch (e) {
          print('Error al generar URL firmada para ${producto.imagenUrl}: $e');
        }
      }
    }

    return productos;
  } catch (e) {
    print('Error al listar productos: $e');
    throw Exception('Error al listar productos: $e');
  }
}

  Future<int> crearProducto(Producto producto) async {
    final response = await _client
        .from('producto')
        .insert(producto.toMap()..removeWhere((key, value) => key == 'idproducto' && value == null))
        .select('idproducto')
        .single();

    return response['idproducto'] as int;
  }

  Future<void> actualizarProducto(Producto producto) async {
    if (producto.idproducto == null) {
      throw Exception('ID de producto es requerido para actualizar.');
    }

    await _client
        .from('producto')
        .update(producto.toMap()..removeWhere((key, value) => key == 'idproducto'))
        .eq('idproducto', producto.idproducto!);
  }

  Future<void> eliminarProducto(int idProducto) async {
    await _client.from('producto').delete().eq('idproducto', idProducto);
  }

Future<String> subirImagen(String filePath, int idProducto) async {
      try {
        final file = File(filePath);
        final fileName = 'uploads/producto_${idProducto}_${DateTime.now().millisecondsSinceEpoch}.jpg';
        print('Subiendo imagen a productos/$fileName');
        await _client.storage
            .from('productos')
            .upload(fileName, file, fileOptions: const FileOptions(upsert: true));
        final signedUrl = await _client.storage.from('productos').createSignedUrl(fileName, 3600); // 1 hour
        print('URL firmada generada: $signedUrl');
        return signedUrl;
      } catch (e) {
        print('Error al subir imagen: $e');
        throw Exception('Error al subir la imagen: $e');
      }
}

  Future<void> eliminarImagen(String imagenUrl) async {
    final path = imagenUrl.split('/').last; // Extrae el nombre del archivo
    await _client.storage.from('productos').remove(['uploads/$path']);
  }
}