import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:mamapola_app_v1/model/entities/proveedor.dart';

class ProveedorRepository {
  final _client = Supabase.instance.client;

  Future<void> createProveedor(int idPersona) async {
    await _client.from('proveedor').insert({'idpersona': idPersona});
  }

  Future<List<Proveedor>> getProveedores() async {
    final data = await _client
        .from('proveedor')
        .select('*, persona(*)');
    return (data as List).map((e) => Proveedor.fromMap(e)).toList();
  }

    Future<void> deleteProveedorByPersona(int idPersona) async {
    await _client.from('proveedor').delete().match({'idpersona': idPersona});
  }

  Future<void> actualizarEmpresaDelProveedor(int idProveedor, int idEmpresa) async {
    await _client
    .from('proveedor')
    .update({'idempresa': idEmpresa})
    .eq('idproveedor', idProveedor);
    }

    Future<void> quitarEmpresaDeProveedores(List<int> ids) async {
  await _client
      .from('proveedor')
      .update({'idempresa': null})
      .inFilter('idproveedor', ids);
}

Future<void> asignarProveedorAEmpresa(int idProveedor, int idEmpresa) async {
  await _client
      .from('proveedor')
      .update({'idempresa': idEmpresa})
      .eq('idproveedor', idProveedor);
}

Future<void> desasignarProveedorDeEmpresa(int idProveedor) async {
  await _client.from('proveedor').update({'idempresa': null}).eq('idproveedor', idProveedor);
}

}