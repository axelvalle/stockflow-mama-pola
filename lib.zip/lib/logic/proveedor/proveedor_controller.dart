import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/model/repository/persona_repository.dart';
import 'package:mamapola_app_v1/model/repository/proveedor_repository.dart';
import 'package:mamapola_app_v1/model/entities/persona.dart';
import 'proveedor_state.dart';

final proveedorControllerProvider = StateNotifierProvider<ProveedorController, ProveedorState>((ref) {
  return ProveedorController();
});

class ProveedorController extends StateNotifier<ProveedorState> {
  final _personaRepo = PersonaRepository();
  final _proveedorRepo = ProveedorRepository();

  ProveedorController() : super(ProveedorState.initial());

  Future<void> loadProveedores() async {
    state = state.copyWith(isLoading: true);
    try {
      final proveedores = await _proveedorRepo.getProveedores();
      state = state.copyWith(proveedores: proveedores, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> registrarProveedor(Persona persona) async {
    state = state.copyWith(isLoading: true);
    try {
      final idPersona = await _personaRepo.createPersona(persona);
      await _proveedorRepo.createProveedor(idPersona);
      await loadProveedores();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

    Future<void> actualizarProveedor(Persona persona) async {
    state = state.copyWith(isLoading: true);
    try {
      await _personaRepo.updatePersona(persona);
      await loadProveedores();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> eliminarProveedor(int idPersona) async {
    state = state.copyWith(isLoading: true);
    try {
      await _proveedorRepo.deleteProveedorByPersona(idPersona);
      await _personaRepo.deletePersona(idPersona);
      await loadProveedores();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }
        Future<void> asignarProveedor(int idProveedor, int idEmpresa) async {
          state = state.copyWith(isLoading: true);
          try {
            await _proveedorRepo.asignarProveedorAEmpresa(idProveedor, idEmpresa);
            await loadProveedores();
          } catch (e) {
            state = state.copyWith(error: e.toString(), isLoading: false);
          }
        }

  Future<void> desasignarProveedor(int idProveedor) async {
    state = state.copyWith(isLoading: true);
    try {
      await _proveedorRepo.desasignarProveedorDeEmpresa(idProveedor);
      await loadProveedores();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  
}
