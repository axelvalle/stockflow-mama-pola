import 'package:mamapola_app_v1/model/entities/categoria.dart';

class CategoriaState {
  final bool isLoading;
  final List<Categoria> categorias;
  final String? error;

  const CategoriaState({
    this.isLoading = false,
    this.categorias = const [],
    this.error,
  });

  CategoriaState copyWith({
    bool? isLoading,
    List<Categoria>? categorias,
    String? error,
  }) {
    return CategoriaState(
      isLoading: isLoading ?? this.isLoading,
      categorias: categorias ?? this.categorias,
      error: error,
    );
  }
}