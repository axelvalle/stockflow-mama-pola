import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/logic/categoria/categoria_state.dart';
import 'package:mamapola_app_v1/model/entities/categoria.dart';
import 'package:mamapola_app_v1/model/repository/categoria_repository.dart';

final categoriaControllerProvider =
    StateNotifierProvider<CategoriaController, CategoriaState>((ref) {
  return CategoriaController();
});

class CategoriaController extends StateNotifier<CategoriaState> {
  final _repo = CategoriaRepository();

  CategoriaController() : super(const CategoriaState());

  Future<void> cargarCategorias() async {
    state = state.copyWith(isLoading: true);
    try {
      final categorias = await _repo.listarCategorias();
      state = state.copyWith(categorias: categorias, isLoading: false, error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<int> agregarCategoria(Categoria categoria) async {
    state = state.copyWith(isLoading: true);
    try {
      final idCategoria = await _repo.crearCategoria(categoria);
      await cargarCategorias();
      return idCategoria;
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
      rethrow;
    }
  }

  Future<void> actualizarCategoria(Categoria categoria) async {
    state = state.copyWith(isLoading: true);
    try {
      await _repo.actualizarCategoria(categoria);
      await cargarCategorias();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
      rethrow;
    }
  }

  Future<void> eliminarCategoria(int idCategoria) async {
    state = state.copyWith(isLoading: true);
    try {
      await _repo.eliminarCategoria(idCategoria);
      await cargarCategorias();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
      rethrow;
    }
  }
}