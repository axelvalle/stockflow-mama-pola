import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:mamapola_app_v1/model/exceptions/ui_errorhandle.dart';

class UserNotVerifiedException implements Exception {
  final String message;
  UserNotVerifiedException(this.message);
}

class AuthService {
  static final _client = Supabase.instance.client;

  static Future<AuthResponse> login(
      String email, String password, BuildContext context) async {
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user?.emailConfirmedAt == null) {
        await _client.auth.signOut();
        throw UserNotVerifiedException(
          'Tu correo aún no está verificado. Por favor revisa tu bandeja de entrada.',
        );
      }

      return response;
    } catch (e) {
      final errorMsg = e.toString().toLowerCase();

      if (errorMsg.contains('invalid login credentials')) {
        throw Exception('Correo o contraseña incorrectos');
      }

      UIErrorHandler.showError(
        context,
        e,
        displayType: ErrorDisplayType.snackBar,
      );
      rethrow;
    }
  }

  static Future<AuthResponse> register(String email, String password) async {
    try {
      debugPrint('AuthService: Registrando usuario: $email');
      final response = await _client.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      debugPrint('AuthService: Registro respuesta: user: $user');

      if (user != null) {
        // Upsert para evitar error por clave duplicada
        await _client.from('usuarios_app').upsert({
          'id': user.id, 
          'email': user.email,
        }, onConflict: 'email');
        debugPrint('AuthService: Usuario insertado o actualizado en usuarios_app');
      }

      return response;
    } on AuthException catch (e) {
      debugPrint('AuthException en register: ${e.message}');
      rethrow;
    } catch (e, st) {
      debugPrint('Error inesperado en register: $e');
      debugPrint('StackTrace: $st');
      throw Exception('Error en el registro: ${e.toString()}');
    }
  }

  static Future<void> logout(BuildContext context) async {
    try {
      await _client.auth.signOut();
    } catch (e) {
      UIErrorHandler.showError(
        context,
        e,
        displayType: ErrorDisplayType.snackBar,
      );
      rethrow;
    }
  }

  static User? get currentUser => _client.auth.currentUser;
}
