import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mamapola_app_v1/logic/producto/producto_state.dart';
import 'package:mamapola_app_v1/model/entities/producto.dart';
import 'package:mamapola_app_v1/model/repository/producto_repository.dart';

final productoControllerProvider =
    StateNotifierProvider<ProductoController, ProductoState>((ref) {
  return ProductoController();
});

class ProductoController extends StateNotifier<ProductoState> {
  final _repo = ProductoRepository();

  ProductoController() : super(const ProductoState());

  Future<void> cargarProductos() async {
    state = state.copyWith(isLoading: true);
    try {
      final productos = await _repo.listarProductos();
      state = state.copyWith(productos: productos, isLoading: false, error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

Future<int> agregarProducto(Producto producto, String? imagenPath) async {
  state = state.copyWith(isLoading: true);
  try {
    final idProducto = await _repo.crearProducto(producto);
    String? imagenUrl;
    if (imagenPath != null) {
      imagenUrl = await _repo.subirImagen(imagenPath, idProducto);
      await _repo.actualizarProducto(producto.copyWith(idproducto: idProducto, imagenUrl: imagenUrl));
    }
    await cargarProductos();
    return idProducto;
  } catch (e) {
    state = state.copyWith(error: e.toString(), isLoading: false);
    rethrow;
  }
}

Future<void> actualizarProducto(Producto producto, String? imagenPath) async {
  state = state.copyWith(isLoading: true);
  try {
    String? imagenUrl = producto.imagenUrl;
    if (imagenPath != null) {
      if (producto.imagenUrl != null) {
        await _repo.eliminarImagen(producto.imagenUrl!);
      }
      imagenUrl = await _repo.subirImagen(imagenPath, producto.idproducto!);
    }
    await _repo.actualizarProducto(producto.copyWith(imagenUrl: imagenUrl));
    await cargarProductos();
  } catch (e) {
    state = state.copyWith(error: e.toString(), isLoading: false);
    rethrow;
  }
}

  Future<void> eliminarProducto(int idProducto, String? imagenUrl) async {
    state = state.copyWith(isLoading: true);
    try {
      if (imagenUrl != null) {
        await _repo.eliminarImagen(imagenUrl);
      }
      await _repo.eliminarProducto(idProducto);
      await cargarProductos();
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
      rethrow;
    }
  }
}

extension ProductoExtension on Producto {
  Producto copyWith({
    int? idproducto,
    String? nombreproducto,
    double? precio,
    int? idcategoria,
    int? idproveedor,
    String? estado,
    String? imagenUrl,
  }) {
    return Producto(
      idproducto: idproducto ?? this.idproducto,
      nombreproducto: nombreproducto ?? this.nombreproducto,
      precio: precio ?? this.precio,
      idcategoria: idcategoria ?? this.idcategoria,
      idproveedor: idproveedor ?? this.idproveedor,
      estado: estado ?? this.estado,
      imagenUrl: imagenUrl ?? this.imagenUrl,
    );
  }
}