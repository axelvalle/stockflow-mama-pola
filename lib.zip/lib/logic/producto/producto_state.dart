import 'package:mamapola_app_v1/model/entities/producto.dart';

class ProductoState {
  final bool isLoading;
  final List<Producto> productos;
  final String? error;

  const ProductoState({
    this.isLoading = false,
    this.productos = const [],
    this.error,
  });

  ProductoState copyWith({
    bool? isLoading,
    List<Producto>? productos,
    String? error,
  }) {
    return ProductoState(
      isLoading: isLoading ?? this.isLoading,
      productos: productos ?? this.productos,
      error: error,
    );
  }
}